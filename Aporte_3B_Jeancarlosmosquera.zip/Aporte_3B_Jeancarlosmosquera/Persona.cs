﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aporte_3B_Jeancarlosmosquera
{
    class Persona
    {
        public string Nombres { get; set; }
    }
}

